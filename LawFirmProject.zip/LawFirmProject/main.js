const SUPABASE_URL = 'https://qksgqkmctjzmzhzmrbhj.supabase.co';
const SUPABASE_KEY = 'sb_publishable_Hx1bN74JlwOKBW6wv0wRgQ_fkP9N-b5'; 
const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

let currentUser = null;
let currentMonth = new Date().getMonth();
let currentYear = new Date().getFullYear();

let globalUserRole = 'lawyer';
let globalUserName = 'User';

const monthNames = [
    "January", "February", "March", "April", "May", "June", 
    "July", "August", "September", "October", "November", "December"
];

async function checkAuthAndInit() {
    try {
        const { data: { session }, error } = await supabaseClient.auth.getSession();
        
        if (error || !session) {
            window.location.href = 'login.html';
            return;
        }

        currentUser = session.user;
        
        await updateSidebarUserInfo();
        await initializeApp();
        
        supabaseClient.auth.onAuthStateChange((event, session) => {
            if (event === 'SIGNED_OUT') {
                window.location.href = 'login.html';
            }
        });

    } catch (err) {
        console.error('System Initialization error:', err);
    }
}

async function updateSidebarUserInfo() {
    if (!currentUser) return;

    try {
        let displayName = "User";
        let role = "lawyer"; 

        if (currentUser.email) {
            const emailPrefix = currentUser.email.split('@')[0];
            displayName = emailPrefix.charAt(0).toUpperCase() + emailPrefix.slice(1);
            
            const lowerEmail = currentUser.email.toLowerCase();
            if (lowerEmail.includes('secretary') || lowerEmail.includes('admin')) {
                role = 'administrator';
            }
        }

        const { data: profile, error } = await supabaseClient
            .from('profiles')
            .select('*')
            .eq('id', currentUser.id)
            .single();

        if (profile && !error) {
            if (profile.full_name) displayName = profile.full_name;
            if (profile.role) {
                role = profile.role.toLowerCase() === 'secretary' ? 'administrator' : profile.role;
            }
        } else if (currentUser.user_metadata) {
            if (currentUser.user_metadata.full_name) displayName = currentUser.user_metadata.full_name;
            if (currentUser.user_metadata.role) {
                role = currentUser.user_metadata.role.toLowerCase() === 'secretary' ? 'administrator' : currentUser.user_metadata.role;
            }
        }

        globalUserRole = role.toLowerCase();
        globalUserName = displayName;

        const avatarSmall = document.querySelector('.avatar-small');
        if (avatarSmall) {
            avatarSmall.textContent = getInitials(displayName);
        }

        const userName = document.querySelector('.user-name');
        const userRole = document.querySelector('.user-role');
        
        if (userName) userName.textContent = `Atty. ${displayName}`;
        if (userRole) userRole.textContent = role.charAt(0).toUpperCase() + role.slice(1);

        const isLawyer = role.toLowerCase() === 'lawyer';

        const lawyersCountEl = document.getElementById('stat-lawyers-val');
        if (lawyersCountEl) {
            const lawyersCard = lawyersCountEl.closest('.stat-card') || lawyersCountEl.parentElement.parentElement;
            const statsGrid = document.querySelector('.stats-grid');
            
            if (lawyersCard) {
                lawyersCard.style.display = isLawyer ? 'none' : 'flex';
                if (statsGrid) {
                    statsGrid.style.gridTemplateColumns = isLawyer ? 'repeat(3, 1fr)' : 'repeat(4, 1fr)';
                }
            }
        }

        const widgetCards = document.querySelectorAll('.calendar-sidebar-widgets .widget-card');
        widgetCards.forEach(card => {
            const heading = card.querySelector('h4');
            if (heading && heading.textContent.toLowerCase().includes('lawyers')) {
                card.style.display = isLawyer ? 'none' : 'block';
            }
        });

        const manageLawyersNav = document.getElementById('nav-manage-lawyers');
        if (manageLawyersNav) {
            manageLawyersNav.style.display = isLawyer ? 'none' : 'flex';
        }

        const uploadDocBtn = document.getElementById('btn-upload-doc');
        if (uploadDocBtn) {
            uploadDocBtn.style.display = (globalUserRole === 'administrator') ? 'none' : 'flex';
        }

        const addEventBtn = document.getElementById('btn-add-event-header');
        if (addEventBtn) {
            addEventBtn.style.display = 'flex';
        }

    } catch (error) {
        console.error('Error fetching/updating profile UI:', error);
    }
}

function getInitials(name) {
    if (!name) return 'U';
    return name
        .trim()
        .split(/\s+/)
        .map(word => word.charAt(0))
        .join('')
        .toUpperCase()
        .substring(0, 2);
}

function setupRealtimeSubscriptions() {
    supabaseClient.channel('public-changes')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'calendar_events' }, () => {
            generateCalendarGrid();
            renderDashboardContent();
            updateDashboardStats();
            renderActiveConflictsWidget();
            renderLawyerStatusWidget();
            renderDeadlinesInSchedule();
            renderTimelineInSchedule();
            renderNotificationsList();
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'documents' }, () => {
            renderDocumentList();
            renderRecentDocumentsInSchedule();
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'cases' }, () => {
            renderMyCasesTab();
            updateDashboardStats();
        })
        .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, () => {
            renderManageLawyersList();
            renderLawyerStatusWidget();
        })
        .subscribe();
}

async function initializeApp() {
    setupRealtimeSubscriptions();
    await updateDashboardStats();
    await renderDashboardContent();
    setupDashboardButtons();
    
    generateCalendarGrid();
    setupCalendarControls();
    
    prepareEventModal();
    setupAddEventModal();
    setupUploadModal(); 
    setupDocumentFilters();
    setupDayDetailsModal(); 
    
    setupAddLawyerModal(); 
    setupEditLawyerModal();
    setupArchiveLawyerModal(); 
    await renderManageLawyersList(); 

    await renderResourcesWidget();
    await renderActiveConflictsWidget();
    await renderLawyerStatusWidget(); 
    
    setupScheduleTabs();
    setupScheduleButtons();
    await renderMyScheduleContent();
    
    setupNotificationTabs();
    await renderNotificationsList();
    await renderEmailQueueList();
    setupNotificationActions(); 
    
    setupLogoutValidation();
}

const navItems = document.querySelectorAll('.nav-links li');

navItems.forEach(item => {
    item.addEventListener('click', async function() {
        const target = this.getAttribute('data-target');
        if (!target) return;

        navItems.forEach(i => i.classList.remove('active'));
        this.classList.add('active');

        document.querySelectorAll('.view-section').forEach(section => {
            section.classList.add('hidden');
        });

        const activeSection = document.getElementById(target);
        if (activeSection) {
            activeSection.classList.remove('hidden');
        }

        if (target === 'calendar-view') {
            generateCalendarGrid();
            await renderActiveConflictsWidget();
            await renderLawyerStatusWidget();
            await renderResourcesWidget(); 
        }
        
        if (target === 'documents-view') {
            await renderDocumentList(); 
        }
        
        if (target === 'dashboard-view') {
            await updateDashboardStats();
            await renderDashboardContent();
        }
        
        if (target === 'schedule-view') {
            await renderMyScheduleContent();
        }
        
        if (target === 'notifications-view') {
            await renderNotificationsList();
            await renderEmailQueueList();
        }

        if (target === 'manage-lawyers-view') {
            await renderManageLawyersList();
        }
    });
});

async function updateDashboardStats() {
    try {
        const localDate = new Date();
        const year = localDate.getFullYear();
        const month = String(localDate.getMonth() + 1).padStart(2, '0');
        const day = String(localDate.getDate()).padStart(2, '0');
        const todayStr = `${year}-${month}-${day}`;

        const nextWeekDate = new Date(localDate);
        nextWeekDate.setDate(nextWeekDate.getDate() + 7);
        const nwYear = nextWeekDate.getFullYear();
        const nwMonth = String(nextWeekDate.getMonth() + 1).padStart(2, '0');
        const nwDay = String(nextWeekDate.getDate()).padStart(2, '0');
        const nextWeekStr = `${nwYear}-${nwMonth}-${nwDay}`;

        let casesQuery = supabaseClient.from('cases').select('*', { count: 'exact', head: true }).eq('status', 'active');
        let eventsQuery = supabaseClient.from('calendar_events').select('*, profiles(role)').gte('event_date', todayStr).lte('event_date', nextWeekStr);
        let conflictsQuery = supabaseClient.from('calendar_events').select('*, profiles(role)').gte('event_date', todayStr);

        if (globalUserRole === 'lawyer' && currentUser) {
            casesQuery = casesQuery.eq('lawyer_id', currentUser.id);
            eventsQuery = eventsQuery.or(`assigned_to.eq.${currentUser.id},is_general.eq.true`);
            conflictsQuery = conflictsQuery.or(`assigned_to.eq.${currentUser.id},is_general.eq.true`);
        }

        let casesCount = 0;
        try {
            const res = await casesQuery;
            if (!res.error) casesCount = res.count;
        } catch(e) {}

        const { data: upcomingEvents } = await eventsQuery;
        const deadlinesCount = upcomingEvents ? upcomingEvents.length : 0;

        const { data: allUpcomingEvents } = await conflictsQuery;
        let conflictsCount = 0;
        if (allUpcomingEvents) {
            allUpcomingEvents.forEach(ev => {
                if (ev.is_conflict) {
                    conflictsCount++;
                }
            });
        }

        const { count: lawyersCount } = await supabaseClient
            .from('profiles')
            .select('*', { count: 'exact', head: true })
            .eq('status', 'active')
            .eq('role', 'lawyer');

        const casesEl = document.getElementById('stat-cases-val');
        const deadlinesEl = document.getElementById('stat-deadlines-val');
        const conflictsEl = document.getElementById('stat-conflicts-val');
        const lawyersEl = document.getElementById('stat-lawyers-val');

        if (casesEl) casesEl.innerText = casesCount || 0;
        if (deadlinesEl) deadlinesEl.innerText = deadlinesCount;
        if (conflictsEl) conflictsEl.innerText = conflictsCount;
        if (lawyersEl) lawyersEl.innerText = lawyersCount || 0;

    } catch (error) {
        console.error('Error updating dashboard stats:', error);
    }
}

async function renderDashboardContent() {
    const deadlineList = document.getElementById('deadline-list-inject');
    const conflictList = document.getElementById('conflict-list-inject');
    const timeframeLabel = document.getElementById('deadline-timeframe-label');
    
    if (!deadlineList || !conflictList) return;

    try {
        const localDate = new Date();
        const year = localDate.getFullYear();
        const month = String(localDate.getMonth() + 1).padStart(2, '0');
        const day = String(localDate.getDate()).padStart(2, '0');
        const todayStr = `${year}-${month}-${day}`;

        let dlQuery = supabaseClient
            .from('calendar_events')
            .select('*, profiles(full_name, role), clients(client_name)')
            .gte('event_date', todayStr)
            .order('event_date', { ascending: true })
            .limit(50); 

        if (globalUserRole === 'lawyer' && currentUser) {
            dlQuery = dlQuery.or(`assigned_to.eq.${currentUser.id},is_general.eq.true`);
        }

        const { data: allDeadlines, error: dlError } = await dlQuery;
        
        if (dlError) console.error("Error fetching deadlines:", dlError);

        let visibleDeadlines = allDeadlines ? allDeadlines.slice(0, 5) : [];

        if (visibleDeadlines.length > 0) {
            if (timeframeLabel) {
                const nearestDate = new Date(visibleDeadlines[0].event_date);
                const todayDate = new Date(todayStr);
                const diffTime = nearestDate - todayDate;
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                if (diffDays === 0) {
                    timeframeLabel.innerText = "Today";
                    timeframeLabel.style.color = "#ef4444"; 
                } else if (diffDays === 1) {
                    timeframeLabel.innerText = "Tomorrow";
                    timeframeLabel.style.color = "#f97316"; 
                } else {
                    timeframeLabel.innerText = `In ${diffDays} days`;
                    timeframeLabel.style.color = "#64748b"; 
                }
            }

            deadlineList.innerHTML = visibleDeadlines.map(d => {
                const priority = 'High'; 
                const assignedName = d.is_general ? 'All Lawyers' : (d.profiles && d.profiles.full_name ? d.profiles.full_name : 'Unassigned');
                const clientName = d.clients ? d.clients.client_name : 'No Client';
                const isGeneralBadge = d.is_general ? '<span style="background:#dbeafe; color:#1d4ed8; font-size:10px; padding:3px 8px; border-radius:10px; margin-left:8px;">Firm-wide</span>' : '';
                
                return `
                    <div style="background:#fff; border:1px solid #f1f5f9; padding:20px; border-radius:15px; margin-bottom:15px; display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <h4 style="font-size:15px;">
                                ${d.title || 'Untitled Event'} 
                                <span style="background:#fee2e2; color:#ef4444; font-size:10px; padding:3px 8px; border-radius:10px; margin-left:8px;">
                                    ${priority}
                                </span>
                                ${isGeneralBadge}
                            </h4>
                            <p style="font-size:13px; color:#64748b; margin-top:4px;"><i class="fa-solid fa-location-dot"></i> ${d.location || 'No location'} • Client: ${clientName} • Atty. ${assignedName}</p>
                            <div style="margin-top:10px; font-size:12px; color:#94a3b8;">
                                <i class="fa-regular fa-calendar"></i> ${formatDate(d.event_date)} at ${d.time || 'TBD'}
                            </div>
                        </div>
                        <button style="padding:10px 18px; border:1px solid #e2e8f0; background:white; border-radius:10px; cursor:pointer; font-weight:600;" onclick="document.querySelector('.nav-links li[data-target=\\'schedule-view\\']').click()">
                            View
                        </button>
                    </div>
                `;
            }).join('');
        } else {
            if (timeframeLabel) {
                timeframeLabel.innerText = "No events";
                timeframeLabel.style.color = "#64748b";
            }
            deadlineList.innerHTML = '<p style="color:#64748b; text-align:center; padding:20px;">No upcoming deadlines</p>';
        }

        let evQuery = supabaseClient.from('calendar_events').select('*, profiles(role)').gte('event_date', todayStr).eq('is_conflict', true);
        if (globalUserRole === 'lawyer' && currentUser) {
            evQuery = evQuery.or(`assigned_to.eq.${currentUser.id},is_general.eq.true`);
        }
        
        const { data: allUpcomingEvents, error: evError } = await evQuery;

        let conflictsHtml = '';
        let conflictCount = 0;
        
        if (allUpcomingEvents) {
            allUpcomingEvents.forEach(ev => {
                if (conflictCount < 4) {
                    conflictCount++;
                    conflictsHtml += `
                        <div style="background:#fff5f5; border:1px solid #fed7d7; padding:15px; border-radius:10px; margin-bottom:12px;">
                            <h5 style="font-size:13px; color:#1e293b; margin-bottom:4px;">Conflict Detected!</h5>
                            <p style="font-size:11px; color:#64748b; margin-bottom:8px;">Schedule conflict on ${formatDate(ev.event_date)} at ${ev.time}.</p>
                            <span style="background:#ef4444; color:white; padding:4px 8px; border-radius:6px; font-size:10px; font-weight:bold;">
                                Needs Resolution
                            </span>
                        </div>
                    `;
                }
            });
        }

        if (conflictCount > 0) {
            conflictList.innerHTML = conflictsHtml;
        } else {
            conflictList.innerHTML = '<p style="color:#64748b; text-align:center; padding:20px;">No active conflicts</p>';
        }

    } catch (error) {
        console.error('Error rendering dashboard content:', error);
    }
}

function setupDashboardButtons() {
    const viewCalendarBtn = document.getElementById('btn-dash-view-calendar');
    if (viewCalendarBtn) {
        viewCalendarBtn.addEventListener('click', () => {
            const calendarNavLink = document.querySelector('.nav-links li[data-target="calendar-view"]');
            if (calendarNavLink) calendarNavLink.click();
        });
    }
}

function setupCalendarControls() {
    const prevBtn = document.getElementById('prevMonth');
    const nextBtn = document.getElementById('nextMonth');

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            currentMonth--;
            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            }
            generateCalendarGrid();
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            currentMonth++;
            if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }
            generateCalendarGrid();
        });
    }
}

async function generateCalendarGrid() {
    const grid = document.getElementById('calendar-days');
    const headerTitle = document.getElementById('currentMonthYear');
    
    if (!grid || !headerTitle) return;

    headerTitle.innerText = `${monthNames[currentMonth]} ${currentYear}`;
    grid.innerHTML = '';

    const firstDay = new Date(currentYear, currentMonth, 1).getDay();
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const today = new Date();

    const startDate = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-01`;
    const endDate = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${daysInMonth}`;

    let eventsQuery = supabaseClient
        .from('calendar_events')
        .select('*, profiles(full_name, role), clients(client_name)') 
        .gte('event_date', startDate)
        .lte('event_date', endDate);

    if (globalUserRole === 'lawyer' && currentUser) {
        eventsQuery = eventsQuery.or(`assigned_to.eq.${currentUser.id},is_general.eq.true`);
    }

    const { data: calendarEvents, error } = await eventsQuery;

    if (error) console.error("Calendar fetch error:", error);

    const eventsByDay = {};
    if (calendarEvents) {
        calendarEvents.forEach(event => {
            const day = new Date(event.event_date).getDate();
            if (!eventsByDay[day]) eventsByDay[day] = [];
            eventsByDay[day].push(event);
        });
    }

    for (let i = 0; i < firstDay; i++) {
        grid.innerHTML += `<div class="day-cell" style="background:transparent; border:none; box-shadow:none;"></div>`;
    }

    for (let i = 1; i <= daysInMonth; i++) {
        const isCurrent = (i === today.getDate() && 
                          currentMonth === today.getMonth() && 
                          currentYear === today.getFullYear());
        
        let eventsHtml = '<div class="day-events-container">';
        
        if (eventsByDay[i]) {
            eventsByDay[i].forEach(ev => {
                const styleClass = ev.is_conflict ? 'cal-event-conflict' : (ev.is_general ? 'cal-event-general' : 'cal-event-normal');
                const iconHtml = ev.is_conflict ? '<i class="fa-solid fa-triangle-exclamation"></i>' : (ev.is_general ? '<i class="fa-solid fa-building"></i> ' : '');
                
                let lawyerName = '';
                if (ev.is_general) {
                    lawyerName = 'All Lawyers';
                } else if (ev.profiles && ev.profiles.full_name) {
                    lawyerName = ev.profiles.full_name.split(' ')[0]; 
                } else {
                    lawyerName = 'Unassigned';
                }

                const clientNameStr = (ev.clients && ev.clients.client_name) ? `Client: ${ev.clients.client_name} | ` : '';
                eventsHtml += `<div class="cal-event-tag ${styleClass}" title="${clientNameStr}${ev.title}">${iconHtml} ${ev.time || ''} ${ev.title || ''} - Atty. ${lawyerName}</div>`;
            });
        }
        
        eventsHtml += '</div>';

        const dateStrParam = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
        
        grid.innerHTML += `
            <div class="day-cell ${isCurrent ? 'today' : ''}" onclick="openDayDetails('${dateStrParam}')" style="cursor: pointer; transition: 0.2s;" onmouseover="this.style.backgroundColor='#f8fafc'" onmouseout="this.style.backgroundColor='white'">
                <span class="day-number ${isCurrent ? 'highlight-blue' : ''}">${i}</span>
                ${eventsHtml}
            </div>
        `;
    }
}

function setupDayDetailsModal() {
    const closeBtn = document.getElementById('close-day-details-btn');
    const modal = document.getElementById('day-details-modal');

    if (closeBtn && modal) {
        closeBtn.addEventListener('click', () => {
            modal.classList.add('hidden');
        });
    }
}

window.openDayDetails = async function(dateString) {
    const modal = document.getElementById('day-details-modal');
    const titleEl = document.getElementById('day-details-title');
    const listEl = document.getElementById('day-details-list');

    if (!modal || !titleEl || !listEl) return;

    const dateObj = new Date(dateString);
    titleEl.textContent = `Events for ${dateObj.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`;
    listEl.innerHTML = '<p style="color:#64748b; text-align:center; padding:20px;">Loading events...</p>';
    
    modal.classList.remove('hidden');

    try {
        let eventsQuery = supabaseClient
            .from('calendar_events')
            .select('*, profiles(full_name, role), clients(client_name)')
            .eq('event_date', dateString)
            .order('time', { ascending: true });

        if (globalUserRole === 'lawyer' && currentUser) {
            eventsQuery = eventsQuery.or(`assigned_to.eq.${currentUser.id},is_general.eq.true`);
        }

        const { data: events, error } = await eventsQuery;

        if (error) throw error;

        if (events && events.length > 0) {
            let html = '';
            for (const ev of events) {
                const lawyerName = ev.is_general ? 'All Lawyers' : (ev.profiles?.full_name || 'Unassigned');
                const clientName = ev.clients?.client_name || 'No Client';
                const borderColor = ev.is_conflict ? '#ef4444' : (ev.is_general ? '#8b5cf6' : '#3b82f6');
                const bgColor = ev.is_conflict ? '#fef2f2' : (ev.is_general ? '#f5f3ff' : '#f8fafc');
                const conflictStyle = `border-left: 4px solid ${borderColor}; background: ${bgColor};`;
                const priorityBadge = ev.priority === 'high' ? '<span class="badge-pill bg-red">High Priority</span>' : '';
                const generalBadge = ev.is_general ? '<span style="background:#ede9fe; color:#7c3aed; font-size:11px; padding:2px 10px; border-radius:99px; margin-left:8px;">Firm-wide</span>' : '';

                let caseDetailsHtml = '';
                if (ev.client_id) {
                    const { data: caseData } = await supabaseClient
                        .from('cases')
                        .select('case_number, case_type, case_description')
                        .eq('client_id', ev.client_id)
                        .limit(1)
                        .single();

                    if (caseData) {
                        caseDetailsHtml = `
                            <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid #e2e8f0; font-size: 12px;">
                                <div style="display:flex; gap: 15px; margin-bottom: 6px;">
                                    <span style="color:#475569;"><strong>Case No:</strong> ${caseData.case_number || 'N/A'}</span>
                                    <span style="color:#475569;"><strong>Type:</strong> ${caseData.case_type || 'N/A'}</span>
                                </div>
                                <p style="color:#64748b; margin:0; line-height: 1.4;"><em>"${caseData.case_description || 'No description provided.'}"</em></p>
                            </div>
                        `;
                    }
                }

                html += `
                    <div style="${conflictStyle} border-radius: 8px; padding: 15px; border-top: 1px solid #e2e8f0; border-right: 1px solid #e2e8f0; border-bottom: 1px solid #e2e8f0; margin-bottom:10px;">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom: 8px;">
                            <h4 style="margin:0; font-size:16px; color:#0f172a;">${ev.title} ${priorityBadge} ${generalBadge}</h4>
                            <span style="font-weight:600; color:#3b82f6; font-size:14px;">${ev.time || 'TBD'}</span>
                        </div>
                        <div style="display:flex; flex-direction:column; gap:6px; font-size:13px; color:#475569;">
                            <span><i class="fa-solid fa-location-dot" style="width:16px; color:#94a3b8;"></i> ${ev.location || 'Office'}</span>
                            <span><i class="fa-solid fa-user" style="width:16px; color:#94a3b8;"></i> Client: <strong>${clientName}</strong></span>
                            <span><i class="fa-solid fa-gavel" style="width:16px; color:#94a3b8;"></i> ${ev.is_general ? '<strong>All Lawyers</strong>' : `Atty. ${lawyerName}`}</span>
                        </div>
                        ${caseDetailsHtml}
                    </div>
                `;
            }
            
            if (html === '') {
                listEl.innerHTML = '<p style="color:#64748b; text-align:center; padding:30px;">No events scheduled for this day.</p>';
            } else {
                listEl.innerHTML = html;
            }
        } else {
            listEl.innerHTML = '<p style="color:#64748b; text-align:center; padding:30px;">No events scheduled for this day.</p>';
        }
    } catch (error) {
        console.error("Error fetching day details:", error);
        listEl.innerHTML = '<p style="color:#ef4444; text-align:center; padding:30px;">Failed to load events.</p>';
    }
};

async function renderActiveConflictsWidget() {
    const conflictsWidget = document.getElementById('widget-conflicts-list');
    if (!conflictsWidget) return;

    try {
        const startDate = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-01`;
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        const endDate = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${daysInMonth}`;

        let evQuery = supabaseClient.from('calendar_events').select('*, profiles(role)').gte('event_date', startDate).lte('event_date', endDate).eq('is_conflict', true);
        if (globalUserRole === 'lawyer' && currentUser) {
            evQuery = evQuery.or(`assigned_to.eq.${currentUser.id},is_general.eq.true`);
        }

        const { data: events } = await evQuery;

        if (!events || events.length === 0) {
            conflictsWidget.innerHTML = '<p style="color:#64748b; padding:10px;">No active conflicts</p>';
            return;
        }

        let conflictsHtml = '';
        let conflictCount = 0;

        events.forEach(ev => {
            if (conflictCount < 4) {
                conflictCount++;
                conflictsHtml += `
                    <div style="background:#fff5f5; border:1px solid #fed7d7; padding:15px; border-radius:10px; margin-bottom:12px;">
                        <h5 style="font-size:13px; color:#1e293b; margin-bottom:4px;">Double Booking!</h5>
                        <p style="font-size:11px; color:#64748b; margin-bottom:8px;">Conflict on ${formatDate(ev.event_date)} at ${ev.time}.</p>
                        <span style="background:#ef4444; color:white; padding:4px 8px; border-radius:6px; font-size:10px; font-weight:bold;">
                            Needs Resolution
                        </span>
                    </div>
                `;
            }
        });

        if (conflictCount > 0) {
            conflictsWidget.innerHTML = conflictsHtml;
        } else {
            conflictsWidget.innerHTML = '<p style="color:#64748b; padding:10px;">No active conflicts</p>';
        }

    } catch (error) {
        console.error('Error rendering conflicts:', error);
    }
}

async function renderLawyerStatusWidget() {
    const lawyerList = document.getElementById('lawyer-status-list-sidebar');
    if (!lawyerList) return;

    const isLawyer = globalUserRole === 'lawyer';
    if (isLawyer) return;

    try {
        const { data: lawyers } = await supabaseClient
            .from('profiles')
            .select('*')
            .eq('role', 'lawyer')
            .eq('status', 'active');

        if (!lawyers || lawyers.length === 0) return;

        const localDate = new Date();
        const year = localDate.getFullYear();
        const month = String(localDate.getMonth() + 1).padStart(2, '0');
        const day = String(localDate.getDate()).padStart(2, '0');
        const todayStr = `${year}-${month}-${day}`;

        const { data: todaysEvents } = await supabaseClient
            .from('calendar_events')
            .select('assigned_to, title, is_general')
            .eq('event_date', todayStr);

        const lawyerEventMap = {};
        if (todaysEvents) {
            todaysEvents.forEach(ev => {
                if (ev.is_general) {
                    lawyers.forEach(l => {
                        if (!lawyerEventMap[l.id]) {
                            lawyerEventMap[l.id] = ev.title || 'Firm Event';
                        }
                    });
                } else if (ev.assigned_to) {
                    if (!lawyerEventMap[ev.assigned_to]) {
                        lawyerEventMap[ev.assigned_to] = ev.title || 'Event';
                    }
                }
            });
        }

        lawyerList.innerHTML = lawyers.map(l => {
            const eventTitle = lawyerEventMap[l.id];
            
            if (eventTitle) {
                const displayTitle = eventTitle.length > 15 ? eventTitle.substring(0, 15) + '...' : eventTitle;
                return `
                    <li style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid #f1f5f9; font-size:13px;">
                        <span title="${eventTitle}"><i class="fa-solid fa-circle" style="color:#ef4444; font-size:8px; margin-right:8px;"></i>${l.full_name || 'Unknown'}</span>
                        <span class="tag" style="background:#fee2e2; color:#ef4444; font-size:10px; padding:3px 8px; border-radius:4px; font-weight:bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 90px;" title="${eventTitle}">${displayTitle}</span>
                    </li>
                `;
            } else {
                return `
                    <li style="display:flex; justify-content:space-between; align-items:center; padding:10px 0; border-bottom:1px solid #f1f5f9; font-size:13px;">
                        <span><i class="fa-solid fa-circle" style="color:#22c55e; font-size:8px; margin-right:8px;"></i>${l.full_name || 'Unknown'}</span>
                        <span class="tag tag-avail" style="background:#dcfce7; color:#22c55e; font-size:10px; padding:3px 8px; border-radius:4px; font-weight:bold;">Available</span>
                    </li>
                `;
            }
        }).join('');

    } catch (error) {
        console.error('Error rendering lawyer status:', error);
    }
}

function setupDocumentFilters() {
    const searchInput = document.getElementById('doc-search-input');
    const filterSelect = document.getElementById('doc-filter');

    if (searchInput && filterSelect) {
        searchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value;
            const filterVal = filterSelect.value;
            renderDocumentList(searchTerm, filterVal);
        });

        filterSelect.addEventListener('change', (e) => {
            const filterVal = e.target.value;
            const searchTerm = searchInput.value;
            renderDocumentList(searchTerm, filterVal);
        });
    }
}

function getCategoryColor(type) {
    const t = (type || '').toLowerCase();
    if (t === 'motion') return { bg: '#e0e7ff', text: '#2563eb' }; 
    if (t === 'contract') return { bg: '#dcfce7', text: '#16a34a' }; 
    if (t === 'pleading') return { bg: '#f3e8ff', text: '#9333ea' }; 
    if (t === 'evidence') return { bg: '#fef08a', text: '#ea580c' }; 
    if (t === 'order') return { bg: '#fee2e2', text: '#dc2626' }; 
    if (t === 'transcript') return { bg: '#ffedd5', text: '#c2410c' }; 
    if (t === 'estate') return { bg: '#fae8ff', text: '#a855f7' }; 
    return { bg: '#f1f5f9', text: '#475569' }; 
}

function generateTagsHtml(tagsStr) {
    if (!tagsStr) return '';
    const tags = tagsStr.split(',').map(t => t.trim()).filter(t => t);
    return tags.map(t => `<span style="border: 1px solid #e2e8f0; padding: 2px 10px; border-radius: 99px; font-size: 11px; color: #475569; font-weight: 500;">${t}</span>`).join('');
}

async function renderDocumentList(searchQuery = '', filterType = 'all') {
    const container = document.getElementById('documents-grid-inject');
    const countEl = document.getElementById('docs-found-count');
    if (!container || !currentUser) return;

    try {
        let query = supabaseClient
            .from('documents')
            .select('*, profiles(full_name)')
            .order('created_at', { ascending: false })
            .limit(50); 

        if (globalUserRole !== 'administrator') {
            query = query.eq('uploaded_by', currentUser.id); 
        }

        if (filterType && filterType !== 'all') {
            query = query.eq('type', filterType.toLowerCase());
        }

        if (searchQuery) {
            query = query.ilike('title', `%${searchQuery}%`); 
        }

        const { data: documents, error } = await query;

        if (error) throw error;

        if (documents && documents.length > 0) {
            container.innerHTML = documents.map(doc => {
                const actualUrl = doc.file_url ? doc.file_url : '#';
                const onBtnClick = doc.file_url 
                    ? `window.open('${doc.file_url}', '_blank')` 
                    : `alert('No file attached to this record in the database.')`;
                
                const onDownloadClick = doc.file_url 
                    ? `forceDownload('${doc.file_url}', '${doc.title.replace(/'/g, "\\'")}')` 
                    : `alert('No file attached to this record in the database.')`;

                const typeColor = getCategoryColor(doc.type);

                return `
                <div class="doc-card" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; box-sizing: border-box;">
                    <div style="display: flex; gap: 15px; margin-bottom: 20px; align-items: flex-start;">
                        <div style="background: #eff6ff; color: #3b82f6; width: 42px; height: 42px; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                            <i class="fa-solid fa-file-lines" style="font-size: 18px;"></i>
                        </div>
                        <div>
                            <h4 style="font-size: 14px; font-weight: 600; color: #0f172a; margin: 0 0 6px 0; word-break: break-word;">${doc.title || 'Untitled Document'}</h4>
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <span style="background: ${typeColor.bg}; color: ${typeColor.text}; padding: 3px 8px; border-radius: 12px; font-size: 10px; font-weight: 600; text-transform: lowercase;">${doc.type || 'document'}</span>
                                <span style="font-size: 11px; color: #64748b;">${doc.size || '0 KB'}</span>
                            </div>
                        </div>
                    </div>

                    <div style="font-size: 12px; color: #475569; margin-bottom: 15px; display: flex; flex-direction: column; gap: 8px;">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <i class="fa-solid fa-tag" style="color: #94a3b8; width: 14px; text-align: center;"></i> 
                            ${doc.case_number || 'No Case Number'}
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <i class="fa-regular fa-user" style="color: #94a3b8; width: 14px; text-align: center;"></i> 
                            ${doc.profiles?.full_name || 'System'}
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <i class="fa-regular fa-calendar" style="color: #94a3b8; width: 14px; text-align: center;"></i> 
                            ${formatDate(doc.created_at)}
                        </div>
                    </div>

                    <div style="display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 20px;">
                        ${generateTagsHtml(doc.tags)}
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; border-top: 1px solid #f1f5f9; padding-top: 15px;">
                        <button onclick="${onBtnClick}" style="padding: 10px; border: 1px solid #e2e8f0; background: white; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 12px; color: #0f172a; transition: 0.2s; display: flex; justify-content: center; align-items: center; gap: 6px;" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='white'">
                            <i class="fa-regular fa-eye"></i> View
                        </button>
                        <button onclick="${onDownloadClick}" style="padding: 10px; border: 1px solid #e2e8f0; background: white; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 12px; color: #0f172a; transition: 0.2s; display: flex; justify-content: center; align-items: center; gap: 6px;" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='white'">
                            <i class="fa-solid fa-download"></i> Download
                        </button>
                    </div>
                </div>
            `}).join('');

            if (countEl) countEl.textContent = `Found ${documents.length} document${documents.length > 1 ? 's' : ''}`;
        } else {
            container.innerHTML = '<p style="color:#64748b; grid-column: 1 / -1; text-align:center; padding: 40px;">No documents match your search/filter.</p>';
            if (countEl) countEl.textContent = `Found 0 documents`;
        }
    } catch (error) {
        console.error('Error rendering documents:', error);
    }
}

async function forceDownload(url, filename) {
    if (!url || url === '#') { 
        alert('File URL is missing.'); 
        return; 
    }
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("Network response was not ok");
        
        const blob = await response.blob();
        
        const blobUrl = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = blobUrl;
        a.download = filename; 
        document.body.appendChild(a);
        
        a.click(); 
        
        window.URL.revokeObjectURL(blobUrl);
        document.body.removeChild(a);
    } catch (e) {
        console.error('Download failed, opening in new tab instead', e);
        window.open(url, '_blank'); 
    }
}

async function renderMyScheduleContent() {
    if (!currentUser) return;

    await updateScheduleProfileHeader();
    await renderTimelineInSchedule();
    await renderRecentDocumentsInSchedule();
    await renderDeadlinesInSchedule();
    await updateScheduleStats();
    
    await renderMyCasesTab();
    renderPerformanceTab();
}

async function updateScheduleProfileHeader() {
    if (!currentUser) return;

    try {
        let displayName = "User";
        let role = "Lawyer";
        let specialization = "General Practice";

        if (currentUser.email) {
            const emailPrefix = currentUser.email.split('@')[0];
            displayName = emailPrefix.charAt(0).toUpperCase() + emailPrefix.slice(1);
            
            const lowerEmail = currentUser.email.toLowerCase();
            if (lowerEmail.includes('secretary') || lowerEmail.includes('admin')) {
                role = 'Administrator';
                specialization = 'Firm Administration';
            }
        }

        const { data: profile } = await supabaseClient
            .from('profiles')
            .select('*')
            .eq('id', currentUser.id)
            .single();

        if (profile) {
            if (profile.full_name) displayName = profile.full_name;
            if (profile.role) role = profile.role.toLowerCase() === 'secretary' ? 'Administrator' : profile.role;
            if (profile.specialization) specialization = profile.specialization;
            
            const phoneEl = document.querySelector('.contact-text span:last-child');
            if (phoneEl) phoneEl.innerHTML = `<i class="fa-solid fa-phone"></i> ${profile.phone || '(555) 000-0000'}`;
        } else if (currentUser.user_metadata) {
            if (currentUser.user_metadata.full_name) displayName = currentUser.user_metadata.full_name;
            if (currentUser.user_metadata.role) {
                role = currentUser.user_metadata.role.toLowerCase() === 'secretary' ? 'Administrator' : currentUser.user_metadata.role;
            }
        }

        const avatarLarge = document.querySelector('.avatar-large');
        if (avatarLarge) {
            avatarLarge.textContent = getInitials(displayName);
        }

        const nameEl = document.querySelector('.profile-info-flex h2');
        const roleEl = document.querySelector('.role-text');
        const emailEl = document.querySelector('.contact-text span:first-child');

        if (nameEl) nameEl.textContent = `Atty. ${displayName}`;
        if (roleEl) roleEl.textContent = `${role.charAt(0).toUpperCase() + role.slice(1)} - ${specialization}`;
        if (emailEl) emailEl.innerHTML = `<i class="fa-regular fa-envelope"></i> ${currentUser.email}`;
        
    } catch (error) {
        console.error('Error updating profile header in My Schedule:', error);
    }
}

async function updateScheduleStats() {
    if (!currentUser) return;

    try {
        let activeCases = 0;
        try {
            const { count, error } = await supabaseClient
                .from('cases')
                .select('*', { count: 'exact', head: true })
                .eq('status', 'active')
                .eq('lawyer_id', currentUser.id);
            if (!error) activeCases = count;
        } catch (e) {}

        const localDate = new Date();
        const todayStr = localDate.toISOString().split('T')[0];
        
        const nextWeekDate = new Date(localDate);
        nextWeekDate.setDate(nextWeekDate.getDate() + 7);
        const nextWeekStr = nextWeekDate.toISOString().split('T')[0];

        const { data: upcomingEvents } = await supabaseClient
            .from('calendar_events')
            .select('*')
            .gte('event_date', todayStr)
            .lte('event_date', nextWeekStr)
            .or(`assigned_to.eq.${currentUser.id},is_general.eq.true`);

        const deadlinesCount = upcomingEvents ? upcomingEvents.length : 0;

        const { data: pastEvents } = await supabaseClient
            .from('calendar_events')
            .select('*')
            .lt('event_date', todayStr)
            .or(`assigned_to.eq.${currentUser.id},is_general.eq.true`);
            
        const completedCount = pastEvents ? pastEvents.length : 0;

        const statCards = document.querySelectorAll('.sched-stat-card h3');
        if (statCards.length >= 4) {
            statCards[0].textContent = activeCases || '0';
            statCards[1].textContent = deadlinesCount || '0';
            statCards[2].textContent = completedCount || '0';
            statCards[3].textContent = (activeCases * 4) + 12 || '32'; 
        }
    } catch (error) {
        console.error('Error updating schedule stats:', error);
    }
}

async function renderTimelineInSchedule() {
    const timeline = document.getElementById('timeline-inject');
    if (!timeline || !currentUser) return;

    try {
        const localDate = new Date();
        const year = localDate.getFullYear();
        const month = String(localDate.getMonth() + 1).padStart(2, '0');
        const day = String(localDate.getDate()).padStart(2, '0');
        const todayStr = `${year}-${month}-${day}`;
        
  
        const { data: events } = await supabaseClient
            .from('calendar_events')
            .select('*')
            .eq('event_date', todayStr)
            .or(`assigned_to.eq.${currentUser.id},is_general.eq.true`)
            .order('time', { ascending: true });

        if (events && events.length > 0) {
            timeline.innerHTML = events.map(ev => {
                const colorClass = ev.is_conflict ? 'bar-red' : (ev.is_general ? 'bar-purple' : 'bar-blue');
                const priorityBadge = ev.priority === 'high' ? '<span class="badge-pill bg-red">High Priority</span>' : '';
                const generalBadge = ev.is_general ? '<span class="badge-pill bg-purple">Firm-wide</span>' : '';
                
                return `
                    <div class="timeline-item ${colorClass}">
                        <div class="time-row">
                            <strong>${ev.time || 'All Day'}</strong> 
                            ${priorityBadge}
                            ${generalBadge}
                        </div>
                        <h4>${ev.title}</h4>
                        <div class="timeline-meta">
                            <span><i class="fa-solid fa-location-dot"></i> ${ev.location || 'Office'}</span>
                        </div>
                    </div>
                `;
            }).join('');
        } else {
            timeline.innerHTML = '<p style="color:#64748b; text-align:center; padding:20px;">No events scheduled for today</p>';
        }
    } catch (error) {
        console.error('Error rendering timeline:', error);
    }
}

async function renderRecentDocumentsInSchedule() {
    const list = document.getElementById('recent-docs-inject');
    if (!list || !currentUser) return;

    try {

        const { data: documents } = await supabaseClient
            .from('documents')
            .select('*')
            .eq('uploaded_by', currentUser.id)
            .order('created_at', { ascending: false })
            .limit(3);

        if (documents && documents.length > 0) {
            list.innerHTML = documents.map(doc => `
                <div style="background:#f8fafc; border-radius:10px; padding:15px; margin-bottom:12px; display:flex; align-items:center; gap:15px;">
                    <div style="background:#eff6ff; color:#3b82f6; width:40px; height:40px; border-radius:8px; display:flex; align-items:center; justify-content:center;">
                        <i class="fa-solid fa-file-lines"></i>
                    </div>
                    <div>
                        <h4 style="font-size:13px; color:#1e293b; margin-bottom:4px;">${doc.title}</h4>
                        <p style="font-size:11px; color:#64748b; text-transform:capitalize;">${doc.type || 'Doc'}</p>
                    </div>
                </div>
            `).join('');
        } else {
            list.innerHTML = '<p style="color:#64748b; text-align:center; padding:20px;">No recent documents</p>';
        }
    } catch (error) {
        console.error('Error rendering recent documents:', error);
    }
}

async function renderDeadlinesInSchedule() {
    const list = document.getElementById('upcoming-dl-inject');
    if (!list || !currentUser) return;

    try {
        const localDate = new Date();
        const year = localDate.getFullYear();
        const month = String(localDate.getMonth() + 1).padStart(2, '0');
        const day = String(localDate.getDate()).padStart(2, '0');
        const todayStr = `${year}-${month}-${day}`;
        
        const { data: deadlines } = await supabaseClient
            .from('calendar_events')
            .select('*, clients(client_name)')
            .gte('event_date', todayStr)
            .or(`assigned_to.eq.${currentUser.id},is_general.eq.true`)
            .order('event_date', { ascending: true })
            .limit(5);

        if (deadlines && deadlines.length > 0) {
            list.innerHTML = deadlines.map(dl => {
                const dlDate = new Date(dl.event_date);
                const daysUntil = Math.ceil((dlDate - new Date(todayStr)) / (1000 * 60 * 60 * 24));
                const badgeColor = daysUntil <= 3 ? 'bg-red' : (dl.is_general ? 'bg-purple' : 'bg-gray');
                
                const clientName = dl.clients ? dl.clients.client_name : 'No Client';
                const generalLabel = dl.is_general ? ' • <span style="color:#7c3aed; font-weight:600;">Firm-wide</span>' : '';

                return `
                    <div class="upcoming-dl-item">
                        <div style="display:flex; justify-content:space-between;">
                            <h4>${dl.title}</h4>
                            <span class="badge-pill ${badgeColor}">${daysUntil}d</span>
                        </div>
                        <p>${dl.location || 'Meeting'} • Client: ${clientName}${generalLabel}</p>
                        <small><i class="fa-regular fa-calendar"></i> ${formatDate(dl.event_date)} at ${dl.time}</small>
                    </div>
                `;
            }).join('');
        } else {
            list.innerHTML = '<p style="color:#64748b; text-align:center; padding:20px;">No upcoming events</p>';
        }
    } catch (error) {
        console.error('Error rendering deadlines:', error);
    }
}

async function renderMyCasesTab() {
    const container = document.querySelector('#sched-cases .content-card');
    if (!container || !currentUser) return;

    try {
        const { data: cases, error } = await supabaseClient
            .from('cases')
            .select('*, clients(client_name)')
            .eq('lawyer_id', currentUser.id)
            .order('created_at', { ascending: false });

        if (error) {
            throw error;
        }

        if (cases && cases.length > 0) {
            let html = '<h3 style="margin-bottom: 20px; font-size: 16px;">My Active Cases</h3>';
            cases.forEach(c => {
                const statusColor = c.status === 'active' ? '#3b82f6' : '#64748b';
                const statusBg = c.status === 'active' ? '#eff6ff' : '#f1f5f9';
                
                const clientName = c.clients ? c.clients.client_name : 'No Client';

                html += `
                    <div style="padding: 15px; border: 1px solid #f1f5f9; border-radius: 8px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; background: #fafbfc;">
                        <div>
                            <h4 style="color: #0f172a; margin-bottom: 4px; font-size: 14px;">${c.title} <span style="color:#64748b; font-weight:normal; font-size:12px;">(${clientName})</span></h4>
                            <p style="color: #64748b; font-size: 11px;"><i class="fa-regular fa-clock"></i> Opened: ${formatDate(c.created_at)}</p>
                        </div>
                        <span style="background: ${statusBg}; color: ${statusColor}; padding: 4px 10px; border-radius: 99px; font-size: 10px; font-weight: bold; text-transform: uppercase;">
                            ${c.status}
                        </span>
                    </div>
                `;
            });
            container.innerHTML = html;
        } else {
            container.innerHTML = '<p style="color:#64748b; padding:20px; text-align:center;">No active cases found. Add an event to create a case automatically!</p>';
        }
    } catch (error) {
         console.warn("Could not load my cases tab.");
         container.innerHTML = '<p style="color:#ef4444; padding:20px; text-align:center;">Setup Note: Ensure foreign keys are correct.</p>';
    }
}

function renderPerformanceTab() {
    const container = document.querySelector('#sched-perf .content-card');
    if (!container) return;
    
    container.innerHTML = `
        <h3 style="margin-bottom: 25px; font-size: 16px;">Monthly Performance Overview</h3>
        
        <div style="margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 8px;">
                <span style="font-weight: 500; color: #475569;">Cases Resolved</span>
                <strong style="color: #22c55e;">85%</strong>
            </div>
            <div style="background: #f1f5f9; height: 8px; border-radius: 4px; overflow: hidden;">
                <div style="background: #22c55e; width: 85%; height: 100%; border-radius: 4px;"></div>
            </div>
        </div>
        
        <div style="margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 8px;">
                <span style="font-weight: 500; color: #475569;">Client Satisfaction</span>
                <strong style="color: #3b82f6;">92%</strong>
            </div>
            <div style="background: #f1f5f9; height: 8px; border-radius: 4px; overflow: hidden;">
                <div style="background: #3b82f6; width: 92%; height: 100%; border-radius: 4px;"></div>
            </div>
        </div>
        
        <div style="margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 8px;">
                <span style="font-weight: 500; color: #475569;">Billable Hours Target</span>
                <strong style="color: #a855f7;">78%</strong>
            </div>
            <div style="background: #f1f5f9; height: 8px; border-radius: 4px; overflow: hidden;">
                <div style="background: #a855f7; width: 78%; height: 100%; border-radius: 4px;"></div>
            </div>
        </div>
    `;
}

function setupScheduleTabs() {
    const schedTabs = document.querySelectorAll('.sched-tab-btn');
    
    schedTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const targetId = this.getAttribute('data-scheduletab');
            if(!targetId) return;

            schedTabs.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');

            document.querySelectorAll('.sched-tab-content').forEach(content => {
                content.classList.add('hidden');
            });
            
            const activeContent = document.getElementById(targetId);
            if(activeContent) activeContent.classList.remove('hidden');
        });
    });
}

function setupScheduleButtons() {
    const viewAllDocsBtn = document.getElementById('btn-sched-view-docs');
    if (viewAllDocsBtn) {
        viewAllDocsBtn.addEventListener('click', () => {
            const docsNavLink = document.querySelector('.nav-links li[data-target="documents-view"]');
            if (docsNavLink) docsNavLink.click();
        });
    }
}

async function renderNotificationsList() {
    const list = document.getElementById('notifications-list-inject');
    if (!list || !currentUser) return;

    try {
        const today = new Date();
        const todayStr = today.toISOString().split('T')[0];
        const nextWeek = new Date(today);
        nextWeek.setDate(nextWeek.getDate() + 7);
        const nextWeekStr = nextWeek.toISOString().split('T')[0];

        const { data: events } = await supabaseClient
            .from('calendar_events')
            .select('*, profiles(full_name)')
            .gte('event_date', todayStr)
            .or(`assigned_to.eq.${currentUser.id},is_general.eq.true`);

        let notifications = [];

        if (events && events.length > 0) {
            const seen = {};
            events.forEach(ev => {
                if (!ev.location) return;
                const key = `${ev.event_date}_${ev.location}_${ev.time}`;
                if (seen[key]) {
                    notifications.push({
                        type: 'conflict',
                        title: 'Scheduling Conflict Detected',
                        priority: 'High Priority',
                        priorityColor: '#ef4444',
                        message: `${ev.location} double-booked on ${formatDate(ev.event_date)} at ${ev.time}`,
                        recipient: ev.is_general ? 'All Lawyers' : (ev.profiles?.full_name || 'You'),
                        timeAgo: 'Just now',
                        icon: 'fa-solid fa-triangle-exclamation',
                        iconColor: '#ef4444',
                        unread: true,
                        cardBorder: '#93c5fd',
                        cardBg: '#eff6ff'
                    });
                } else {
                    seen[key] = true;
                }
            });

            events.forEach(ev => {
                if (ev.event_date >= todayStr && ev.event_date <= nextWeekStr) {
                    const evDate = new Date(ev.event_date);
                    const diffDays = Math.ceil((evDate - today) / (1000 * 60 * 60 * 24));
                    
                    const lawyerName = ev.is_general ? 'All Lawyers' : (ev.profiles?.full_name || 'You');

                    if (diffDays <= 3) {
                        notifications.push({
                            type: 'deadline',
                            title: ev.is_general ? 'Firm-wide Event Approaching' : 'Critical Deadline Approaching',
                            priority: 'High Priority',
                            priorityColor: '#ef4444',
                            message: `${ev.title} due in ${diffDays} days (${formatDate(ev.event_date)})`,
                            recipient: lawyerName,
                            timeAgo: '2 hours ago',
                            icon: ev.is_general ? 'fa-solid fa-building' : 'fa-regular fa-calendar',
                            iconColor: ev.is_general ? '#7c3aed' : '#f97316',
                            unread: true,
                            cardBorder: '#93c5fd',
                            cardBg: '#eff6ff'
                        });
                    } else {
                        notifications.push({
                            type: 'reminder',
                            title: ev.is_general ? 'Firm-wide Reminder' : 'Court Appearance Reminder',
                            priority: 'Medium',
                            priorityColor: '#0f172a',
                            message: `${ev.title} scheduled on ${formatDate(ev.event_date)} at ${ev.time}`,
                            recipient: lawyerName,
                            timeAgo: '5 hours ago',
                            icon: 'fa-regular fa-bell',
                            iconColor: '#a855f7',
                            unread: false,
                            cardBorder: '#e2e8f0',
                            cardBg: '#ffffff'
                        });
                    }
                }
            });
        }

        const unreadCount = notifications.filter(n => n.unread).length;
        const highCount = notifications.filter(n => n.priority === 'High Priority').length;
        
        const statUnread = document.querySelector('.notif-sidebar-container .stat-row:nth-child(2) span:nth-child(2)');
        const statHigh = document.querySelector('.notif-sidebar-container .stat-row:nth-child(3) span:nth-child(2)');
        if (statUnread) statUnread.textContent = unreadCount;
        if (statHigh) statHigh.textContent = highCount;

        const headerBadge = document.getElementById('notif-header-badge');
        if (headerBadge) {
            if (unreadCount > 0) {
                headerBadge.textContent = `${unreadCount} unread`;
                headerBadge.style.display = 'inline-block';
            } else {
                headerBadge.style.display = 'none';
            }
        }

        if (notifications.length > 0) {
            list.innerHTML = notifications.map(n => `
                <div class="notif-item-card" style="background: ${n.cardBg}; border: 1px solid ${n.cardBorder}; border-radius: 8px; padding: 20px; margin-bottom: 15px;">
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                        <i class="${n.icon}" style="color: ${n.iconColor}; font-size: 16px;"></i>
                        <h4 style="font-size: 15px; color: #0f172a; margin: 0; font-weight: 600;">${n.title}</h4>
                        ${n.unread ? `<div class="notif-dot" style="width: 8px; height: 8px; background: #3b82f6; border-radius: 50%;"></div>` : ''}
                    </div>
                    <span style="background: ${n.priorityColor}; color: white; padding: 2px 10px; border-radius: 99px; font-size: 11px; font-weight: 600; display: inline-block; margin-bottom: 10px;">
                        ${n.priority}
                    </span>
                    <p style="font-size: 13px; color: #475569; margin-bottom: 12px;">${n.message}</p>
                    <div style="display: flex; justify-content: space-between; align-items: center; font-size: 12px; color: #64748b;">
                        <span>To: ${n.recipient}</span>
                        <div style="display: flex; gap: 15px;">
                            <span style="color: #22c55e;"><i class="fa-regular fa-circle-check"></i> Email sent</span>
                            <span>${n.timeAgo}</span>
                        </div>
                    </div>
                </div>
            `).join('');
        } else {
            list.innerHTML = '<p style="color:#64748b; text-align:center; padding:20px;">No new notifications</p>';
        }
    } catch (error) {
        console.error('Error rendering notifications:', error);
    }
}

async function renderEmailQueueList() {
    const list = document.getElementById('email-queue-list-inject');
    if (!list || !currentUser) return;

    try {
        const todayDate = new Date();
        todayDate.setHours(0,0,0,0);
        
        const { data: events } = await supabaseClient
            .from('calendar_events')
            .select('*, profiles(full_name)')
            .or(`assigned_to.eq.${currentUser.id},is_general.eq.true`)
            .order('event_date', { ascending: true });

        let emails = [];

        if (events && events.length > 0) {
            events.forEach(ev => {
                const evDate = new Date(ev.event_date);
                evDate.setHours(0,0,0,0);

                const isSent = evDate <= todayDate;
                const lawyerName = ev.is_general ? 'All Lawyers' : (ev.profiles?.full_name || 'user');
                const emailAddress = ev.is_general ? 'all.lawyers@lawfirm.com' : lawyerName.toLowerCase().replace(' ', '.') + '@lawfirm.com';

                if (isSent) {
                    emails.push({
                        subject: `Sent: Reminder for ${ev.title}`,
                        recipient: emailAddress,
                        isSent: true,
                        timeText: `Sent at ${formatDate(ev.event_date)} 08:00 AM`,
                        status: 'sent',
                        icon: 'fa-regular fa-circle-check',
                        iconColor: '#22c55e'
                    });
                } else {
                    emails.push({
                        subject: `Upcoming Reminder - ${ev.title}`,
                        recipient: emailAddress,
                        isSent: false,
                        timeText: `Scheduled for ${formatDate(ev.event_date)} 08:00 AM`,
                        status: 'pending',
                        icon: 'fa-regular fa-calendar',
                        iconColor: '#f97316'
                    });
                }
            });
        }

        const sentCount = emails.filter(e => e.isSent).length;
        const statSent = document.querySelector('.notif-sidebar-container .stat-row:nth-child(4) span:nth-child(2)');
        if (statSent) statSent.textContent = sentCount; 

        if (emails.length > 0) {
            list.innerHTML = emails.map(e => `
                <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: flex-start;">
                    <div style="display: flex; gap: 15px;">
                        <i class="fa-regular fa-envelope" style="color: #94a3b8; font-size: 16px; margin-top: 2px;"></i>
                        <div>
                            <h4 style="font-size: 14px; color: #0f172a; margin: 0 0 5px 0; font-weight: 600;">${e.subject}</h4>
                            <p style="font-size: 12px; color: #64748b; margin: 0 0 8px 0;">To: ${e.recipient}</p>
                            <p style="font-size: 12px; color: ${e.iconColor}; margin: 0; font-weight: 500;">
                                <i class="${e.icon}"></i> ${e.timeText}
                            </p>
                        </div>
                    </div>
                    <span style="${e.isSent ? 'background: #ffffff; border: 1px solid #e2e8f0; color: #475569;' : 'background: #0f172a; border: 1px solid #0f172a; color: #ffffff;'} padding: 3px 12px; border-radius: 99px; font-size: 11px; font-weight: 600; text-transform: lowercase;">
                        ${e.status}
                    </span>
                </div>
            `).join('');
        } else {
            list.innerHTML = '<p style="color:#64748b; text-align:center; padding:20px;">No emails in queue</p>';
        }
    } catch (error) {
        console.error('Error rendering email queue:', error);
    }
}

function setupNotificationActions() {
    const btnMarkRead = document.getElementById('btn-mark-read');
    const btnClearRead = document.getElementById('btn-clear-read');
    const btnSendTest = document.getElementById('btn-send-test-email');
    
    if (btnMarkRead) {
        btnMarkRead.addEventListener('click', () => {
            document.querySelectorAll('.notif-dot').forEach(dot => dot.remove());
            
            const statUnread = document.querySelector('.notif-sidebar-container .stat-row:nth-child(2) span:nth-child(2)');
            if (statUnread) statUnread.textContent = '0';
            
            const headerBadge = document.getElementById('notif-header-badge');
            if (headerBadge) headerBadge.style.display = 'none';
            
            alert("All notifications marked as read.");
        });
    }

    if (btnClearRead) {
        btnClearRead.addEventListener('click', () => {
            const list = document.getElementById('notifications-list-inject');
            if (list) {
                const cards = list.querySelectorAll('.notif-item-card'); 
                cards.forEach(card => {
                    if (!card.querySelector('.notif-dot')) {
                        card.remove(); 
                    }
                });
                alert("Read notifications cleared from view.");
            }
        });
    }

    if (btnSendTest) {
        btnSendTest.addEventListener('click', () => {
            const list = document.getElementById('email-queue-list-inject');
            if (list) {
                const newEmail = `
                    <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: flex-start;">
                        <div style="display: flex; gap: 15px;">
                            <i class="fa-regular fa-envelope" style="color: #94a3b8; font-size: 16px; margin-top: 2px;"></i>
                            <div>
                                <h4 style="font-size: 14px; color: #0f172a; margin: 0 0 5px 0; font-weight: 600;">TEST EMAIL: System Check</h4>
                                <p style="font-size: 12px; color: #64748b; margin: 0 0 8px 0;">To: ${currentUser ? currentUser.email : 'you@lawfirm.com'}</p>
                                <p style="font-size: 12px; color: #22c55e; margin: 0; font-weight: 500;">
                                    <i class="fa-regular fa-circle-check"></i> Sent Just Now
                                </p>
                            </div>
                        </div>
                        <span style="background: #ffffff; border: 1px solid #e2e8f0; color: #475569; padding: 3px 12px; border-radius: 99px; font-size: 11px; font-weight: 600; text-transform: lowercase;">
                            sent
                        </span>
                    </div>
                `;
                
                if (list.innerHTML.includes('No emails in queue')) {
                    list.innerHTML = '';
                }
                list.insertAdjacentHTML('afterbegin', newEmail);
                
                const statSent = document.querySelector('.notif-sidebar-container .stat-row:nth-child(4) span:nth-child(2)');
                if (statSent) statSent.textContent = parseInt(statSent.textContent || 0) + 1;

                alert("Test email sent and added to queue!");
            }
        });
    }
}

function setupNotificationTabs() {
    const notifTabs = document.querySelectorAll('.notif-tab-btn');
    
    notifTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const targetId = this.getAttribute('data-notiftab');
            if(!targetId) return;

            notifTabs.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');

            document.querySelectorAll('.notif-content-pane').forEach(content => {
                content.classList.add('hidden');
            });
            
            const activeContent = document.getElementById(targetId);
            if(activeContent) activeContent.classList.remove('hidden');
        });
    });
}

function formatDate(dateString) {
    if (!dateString) return 'No date';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric', 
        year: 'numeric' 
    });
}

function formatTimeAgo(dateString) {
    if (!dateString) return '';
    const now = new Date();
    const date = new Date(dateString);
    const seconds = Math.floor((now - date) / 1000);
    
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)} minutes ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)} hours ago`;
    return `${Math.floor(seconds / 86400)} days ago`;
}

function setupLogoutValidation() {
    const logoutBtn = document.getElementById('logout-sidebar-btn');
    const logoutModal = document.getElementById('logout-modal');
    const cancelLogoutBtn = document.getElementById('btn-cancel-logout');
    const confirmLogoutBtn = document.getElementById('btn-confirm-logout');

    if (logoutBtn && logoutModal) {
        logoutBtn.addEventListener('click', () => {
            logoutModal.classList.remove('hidden');
        });

        if (cancelLogoutBtn) {
            cancelLogoutBtn.addEventListener('click', () => {
                logoutModal.classList.add('hidden');
            });
        }

        if (confirmLogoutBtn) {
            confirmLogoutBtn.addEventListener('click', async () => {
                try {
                    confirmLogoutBtn.innerText = "Logging out...";
                    confirmLogoutBtn.disabled = true;
                    
                    const { error } = await supabaseClient.auth.signOut();
                    
                    if (error) throw error;
                    
                    window.location.href = 'login.html';
                } catch (error) {
                    console.error('Logout error:', error.message);
                    confirmLogoutBtn.innerText = "Logout Failed";
                    confirmLogoutBtn.disabled = false;
                    
                    setTimeout(() => {
                        confirmLogoutBtn.innerText = "Logout";
                    }, 2000);
                }
            });
        }
    } else if (logoutBtn) {
        logoutBtn.addEventListener('click', async () => {
            await supabaseClient.auth.signOut();
            window.location.href = 'login.html';
        });
    }
}

async function prepareEventModal() {
    const lawyerSelect = document.getElementById('event-lawyer');
    const toggleClientBtn = document.getElementById('btn-toggle-client');
    const toggleCaseBtn = document.getElementById('btn-toggle-case');
    const clientSection = document.getElementById('client-details-section');
    const caseSection = document.getElementById('case-details-section');

    try {
        if (globalUserRole === 'administrator') {
            if (lawyerSelect) {
                lawyerSelect.innerHTML = `<option value="">All Lawyers (Firm-wide Event)</option>`;
                lawyerSelect.disabled = true;
                lawyerSelect.style.backgroundColor = '#e2e8f0';
            }
            if (toggleClientBtn) toggleClientBtn.style.display = 'none';
            if (toggleCaseBtn) toggleCaseBtn.style.display = 'none';
            if (clientSection) clientSection.classList.add('hidden');
            if (caseSection) caseSection.classList.add('hidden');

        } else if (globalUserRole === 'lawyer' && currentUser) {
            if (lawyerSelect) {
                lawyerSelect.innerHTML = `<option value="${currentUser.id}">Atty. ${globalUserName}</option>`;
                lawyerSelect.disabled = true;
                lawyerSelect.style.backgroundColor = '#e2e8f0';
            }
            if (toggleClientBtn) toggleClientBtn.style.display = 'block';
            if (toggleCaseBtn) toggleCaseBtn.style.display = 'block';
        }
    } catch (error) {
        console.error('Error loading modal:', error);
    }
}

function setupAddEventModal() {
    const modal = document.getElementById('add-event-modal');
    const openBtn = document.getElementById('btn-add-event-header'); 
    const closeBtn = document.getElementById('close-modal-btn');
    const form = document.getElementById('add-event-form');
    
    const toggleClientBtn = document.getElementById('btn-toggle-client');
    const clientSection = document.getElementById('client-details-section');
    const clientIcon = document.getElementById('client-toggle-icon');

    const toggleCaseBtn = document.getElementById('btn-toggle-case');
    const caseSection = document.getElementById('case-details-section');
    const caseIcon = document.getElementById('case-toggle-icon');

    if (!modal) return;

    if (openBtn) {
        openBtn.addEventListener('click', () => {
            prepareEventModal();
            modal.classList.remove('hidden');
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            modal.classList.add('hidden');
        });
    }

    if (toggleClientBtn && clientSection) {
        toggleClientBtn.addEventListener('click', () => {
            clientSection.classList.toggle('hidden');
            if (clientSection.classList.contains('hidden')) {
                clientIcon.classList.remove('fa-chevron-up');
                clientIcon.classList.add('fa-chevron-down');
            } else {
                clientIcon.classList.remove('fa-chevron-down');
                clientIcon.classList.add('fa-chevron-up');
            }
        });
    }

    if (toggleCaseBtn && caseSection) {
        toggleCaseBtn.addEventListener('click', () => {
            caseSection.classList.toggle('hidden');
            if (caseSection.classList.contains('hidden')) {
                caseIcon.classList.remove('fa-chevron-up');
                caseIcon.classList.add('fa-chevron-down');
            } else {
                caseIcon.classList.remove('fa-chevron-down');
                caseIcon.classList.add('fa-chevron-up');
            }
        });
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault(); 
            
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerText = "Saving...";
            }

            const title = document.getElementById('event-title').value;
            const date = document.getElementById('event-date').value;
            const timeInput = document.getElementById('event-time').value;
            const location = document.getElementById('event-location').value;
            
            let isGeneral = (globalUserRole === 'administrator');
            let assignedLawyerId = isGeneral ? null : currentUser.id;
            
            const fname = document.getElementById('client-fname').value.trim();
            const mi = document.getElementById('client-mi').value.trim();
            const lname = document.getElementById('client-lname').value.trim();
            const cEmail = document.getElementById('client-email').value.trim();
            const cPhone = document.getElementById('client-phone').value.trim();

            let formattedClientName = '';
            if (lname || fname) {
                formattedClientName = `${lname ? lname + ', ' : ''}${fname} ${mi ? mi + '.' : ''}`.trim();
            }

            const caseNum = document.getElementById('case-number-input').value.trim();
            const caseType = document.getElementById('case-type-select').value;
            const caseDesc = document.getElementById('case-desc-input').value.trim();

            let formattedTime = timeInput; 
            if(timeInput) {
                const [h, m] = timeInput.split(':');
                const hour = parseInt(h);
                const ampm = hour >= 12 ? 'PM' : 'AM';
                const formattedH = hour % 12 || 12;
                formattedTime = `${formattedH}:${m} ${ampm}`;
            }

            try {
                let newClientId = null;

                if (formattedClientName) {
                    const { data: clientData, error: clientErr } = await supabaseClient
                        .from('clients')
                        .insert([{
                            client_name: formattedClientName,
                            client_email: cEmail,
                            client_phone: cPhone
                        }])
                        .select('id')
                        .single();

                    if (clientErr) throw new Error(clientErr.message);
                    if (clientData) newClientId = clientData.id;
                }

                let isConflictDetected = false;
                let conflictDesc = '';
                let conflictingEventIds = [];

                if (location && location.trim() !== '') {
                    const { data: locEvents } = await supabaseClient
                        .from('calendar_events')
                        .select('id')
                        .eq('event_date', date)
                        .eq('time', formattedTime)
                        .eq('location', location);
                    
                    if (locEvents && locEvents.length > 0) {
                        isConflictDetected = true;
                        conflictDesc = `Double booking sa ${location} ng ${date} at ${formattedTime}`;
                        locEvents.forEach(e => conflictingEventIds.push(e.id));
                    }
                }

                if (!isGeneral && assignedLawyerId) {
                    const { data: lawEvents } = await supabaseClient
                        .from('calendar_events')
                        .select('id')
                        .eq('event_date', date)
                        .eq('time', formattedTime)
                        .eq('assigned_to', assignedLawyerId);
                    
                    if (lawEvents && lawEvents.length > 0) {
                        isConflictDetected = true;
                        if (!conflictDesc) conflictDesc = `Schedule conflict para sa lawyer ng ${date} at ${formattedTime}`;
                        lawEvents.forEach(e => conflictingEventIds.push(e.id));
                    }
                }

                if (isConflictDetected) {
                    await supabaseClient.from('conflicts').insert([{
                        title: `Conflict: ${title}`,
                        description: conflictDesc,
                        status: 'active'
                    }]);

                    if (conflictingEventIds.length > 0) {
                        await supabaseClient.from('calendar_events').update({ is_conflict: true }).in('id', conflictingEventIds);
                    }
                }

                const eventData = { 
                    title: title, 
                    event_date: date, 
                    time: formattedTime, 
                    location: location,
                    is_general: isGeneral,
                    is_conflict: isConflictDetected
                };

                if (!isGeneral) {
                    eventData.assigned_to = assignedLawyerId;
                }

                if (newClientId) eventData.client_id = newClientId;

                const { error: eventError } = await supabaseClient.from('calendar_events').insert([eventData]);
                if (eventError) throw new Error(eventError.message);

                if (!isGeneral) {
                    const caseData = { 
                        title: title, 
                        status: 'active',
                        case_number: caseNum,
                        case_type: caseType,
                        case_description: caseDesc,
                        lawyer_id: assignedLawyerId
                    };
                    
                    if (newClientId) caseData.client_id = newClientId;

                    const { data: newCase, error: caseError } = await supabaseClient
                        .from('cases')
                        .insert([caseData])
                        .select('id')
                        .single();
                    
                    if (newCase) {
                        await supabaseClient.from('deadlines').insert([{
                            title: `${title} Deadline`,
                            due_date: date,
                            priority: 'High',
                            assigned_to: assignedLawyerId,
                            case_id: newCase.id
                        }]);
                    }
                } 

                alert(isGeneral ? 'Firm-wide event successfully added!' : 'Event, Client, and Case successfully added!');
                
                form.reset(); 
                
                if (clientSection && !clientSection.classList.contains('hidden')) {
                    clientSection.classList.add('hidden');
                    if (clientIcon) {
                        clientIcon.classList.remove('fa-chevron-up');
                        clientIcon.classList.add('fa-chevron-down');
                    }
                }
                if (caseSection && !caseSection.classList.contains('hidden')) {
                    caseSection.classList.add('hidden');
                    if (caseIcon) {
                        caseIcon.classList.remove('fa-chevron-up');
                        caseIcon.classList.add('fa-chevron-down');
                    }
                }

                modal.classList.add('hidden'); 
                
                generateCalendarGrid(); 
                renderResourcesWidget();
                renderActiveConflictsWidget();
                renderLawyerStatusWidget();
                
                updateDashboardStats();
                renderDashboardContent();
                updateScheduleStats();
                renderMyCasesTab(); 
                
                const timeline = document.getElementById('timeline-inject');
                if (timeline && !timeline.parentElement.classList.contains('hidden')) {
                    if (typeof renderTimelineInSchedule === "function") renderTimelineInSchedule();
                }

            } catch (error) {
                console.error('Error saving:', error);
                alert('Error: \n' + error.message);
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerText = "Create Event";
                }
            }
        });
    }
}

async function renderResourcesWidget() {
    const list = document.getElementById('widget-resources-list');
    if (!list) return;

    try {
        const localDate = new Date();
        const year = localDate.getFullYear();
        const month = String(localDate.getMonth() + 1).padStart(2, '0');
        const day = String(localDate.getDate()).padStart(2, '0');
        const todayStr = `${year}-${month}-${day}`;
        
        const { data: events } = await supabaseClient
            .from('calendar_events')
            .select('location')
            .eq('event_date', todayStr);

        const bookedLocations = events ? events.map(e => (e.location || '').trim().toLowerCase()) : [];

        const allRooms = ["Conference Room A", "Conference Room B", "Courtroom 3B"];

        list.innerHTML = allRooms.map(room => {
            const isBusy = bookedLocations.includes(room.toLowerCase());
            
            const tagClass = isBusy ? 'tag-busy' : 'tag-avail';
            const tagText = isBusy ? 'Busy' : 'Available';
            const tagStyle = isBusy 
                ? 'background:#fee2e2; color:#ef4444;' 
                : 'background:#dcfce7; color:#22c55e;';
            
            return `
                <div class="resource-item" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; font-size:13px;">
                    <span style="color:#1e293b; font-weight:500;">${room}</span>
                    <span class="tag ${tagClass}" style="font-size:10px; padding:3px 8px; border-radius:4px; font-weight:bold; ${tagStyle}">
                        ${tagText}
                    </span>
                </div>
            `;
        }).join('');

    } catch (error) {
        console.error('Error rendering resources:', error);
    }
}

function setupUploadModal() {
    const modal = document.getElementById('upload-doc-modal');
    const openBtn = document.getElementById('btn-upload-doc'); 
    const closeBtn = document.getElementById('close-upload-btn');
    const form = document.getElementById('upload-doc-form');

    const dropArea = document.getElementById('drag-drop-area');
    const fileInput = document.getElementById('doc-file-input');
    const dropText = document.getElementById('drag-drop-text');
    let selectedFile = null;

    if (!modal) return;

    if (openBtn) {
        openBtn.addEventListener('click', () => {
            if (globalUserRole === 'administrator') {
                alert('As an administrator, you can view all documents but cannot upload. Please use a lawyer account to upload documents.');
                return;
            }
            modal.classList.remove('hidden');
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            modal.classList.add('hidden');
            if (dropArea && dropText) {
                dropArea.style.borderColor = '#cbd5e1';
                dropArea.style.backgroundColor = '#ffffff';
                dropText.innerText = "Drag and drop files here, or click to browse";
                selectedFile = null;
            }
        });
    }

    if (dropArea && fileInput) {
        dropArea.addEventListener('click', () => {
            fileInput.click();
        });

        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                selectedFile = e.target.files[0];
                dropText.innerText = selectedFile.name; 
                dropArea.style.borderColor = '#3b82f6'; 
                dropArea.style.backgroundColor = '#eff6ff'; 
            }
        });

        dropArea.addEventListener('dragover', (e) => {
            e.preventDefault(); 
            dropArea.style.borderColor = '#3b82f6';
            dropArea.style.backgroundColor = '#eff6ff';
        });

        dropArea.addEventListener('dragleave', () => {
            if (!selectedFile) { 
                dropArea.style.borderColor = '#cbd5e1';
                dropArea.style.backgroundColor = '#ffffff';
            }
        });

        dropArea.addEventListener('drop', (e) => {
            e.preventDefault();
            if (e.dataTransfer.files.length > 0) {
                selectedFile = e.dataTransfer.files[0];
                fileInput.files = e.dataTransfer.files; 
                
                dropText.innerText = selectedFile.name; 
                dropArea.style.borderColor = '#3b82f6';
                dropArea.style.backgroundColor = '#eff6ff';
            }
        });
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault(); 
            
            if (globalUserRole === 'administrator') {
                alert("Administrators are not allowed to upload documents.");
                return;
            }
            
            if (!selectedFile) {
                alert("Please select or drag a file to upload first.");
                return;
            }

            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerText = "Uploading & Processing...";
            }

            const caseNum = document.getElementById('doc-case-num').value || '';
            const category = document.getElementById('doc-category').value || 'Document';
            const tagsInput = document.getElementById('doc-tags').value || '';
            
            const finalTitle = selectedFile.name;
            const fileSizeMb = (selectedFile.size / (1024 * 1024)).toFixed(2) + ' MB';

            try {
                const uniqueFileName = `${Date.now()}_${finalTitle}`;
                const { data: uploadData, error: uploadError } = await supabaseClient
                    .storage
                    .from('documents') 
                    .upload(uniqueFileName, selectedFile);

                if (uploadError) {
                    console.error("Storage Error:", uploadError);
                    throw new Error("Failed to upload file to Storage. Please check if 'documents' bucket exists and is public.");
                }

                const { data: publicUrlData } = supabaseClient
                    .storage
                    .from('documents')
                    .getPublicUrl(uniqueFileName);
                
                const fileUrl = publicUrlData.publicUrl;

                const docData = { 
                    title: finalTitle, 
                    type: category.toLowerCase(), 
                    size: fileSizeMb,
                    file_url: fileUrl, 
                    case_number: caseNum,
                    tags: tagsInput,
                    uploaded_by: currentUser ? currentUser.id : null
                };

                const { error: dbError } = await supabaseClient
                    .from('documents')
                    .insert([docData]);

                if (dbError) {
                    console.error("Database Error:", dbError);
                    throw new Error("File uploaded, but failed to save details to database.");
                }

                alert('Document successfully uploaded and saved!');
                
                form.reset(); 
                if (dropArea && dropText) {
                    dropArea.style.borderColor = '#cbd5e1';
                    dropArea.style.backgroundColor = '#ffffff';
                    dropText.innerText = "Drag and drop files here, or click to browse";
                    selectedFile = null;
                }
                modal.classList.add('hidden'); 
                
                renderDocumentList();
                renderRecentDocumentsInSchedule();

            } catch (error) {
                console.error('Error saving document:', error);
                alert('Error: \n' + error.message);
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerText = "Upload & Process";
                }
            }
        });
    }
}

function setupAddLawyerModal() {
    const modal = document.getElementById('add-lawyer-modal');
    const openBtn = document.getElementById('btn-open-add-lawyer-modal'); 
    const closeBtn = document.getElementById('close-lawyer-modal-btn');
    const form = document.getElementById('add-lawyer-form');

    if (!modal) return;

    if (openBtn) {
        openBtn.addEventListener('click', () => {
            modal.classList.remove('hidden');
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            modal.classList.add('hidden');
        });
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault(); 
            
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerText = "Registering...";
            }

            const fname = document.getElementById('add-lawyer-fname').value.trim();
            const mi = document.getElementById('add-lawyer-mi').value.trim();
            const lname = document.getElementById('add-lawyer-lname').value.trim();
            const email = document.getElementById('add-lawyer-email').value.trim();
            const phone = document.getElementById('add-lawyer-phone').value.trim(); 
            const password = document.getElementById('add-lawyer-password').value;
            const spec = document.getElementById('add-lawyer-spec').value;

            const formattedName = `${fname} ${mi ? mi + '. ' : ''}${lname}`.trim();

            try {
                const { data, error } = await supabaseClient.auth.signUp({
                    email: email,
                    password: password,
                    options: {
                        data: {
                            full_name: formattedName,
                            role: 'lawyer',
                            specialization: spec,
                            phone: phone
                        }
                    }
                });

                if (error) {
                    throw new Error("Failed to register lawyer: " + error.message);
                }

                 await supabaseClient.from('profiles').insert([{
                     id: data.user ? data.user.id : crypto.randomUUID(), 
                     full_name: formattedName,
                     role: 'lawyer',
                     specialization: spec,
                     phone: phone, 
                     status: 'active'
                 }]);

                alert(`Lawyer Atty. ${formattedName} successfully registered!`);
                form.reset(); 
                modal.classList.add('hidden'); 
                
                renderLawyerStatusWidget();
                prepareEventModal();
                renderManageLawyersList(); 

            } catch (error) {
                console.error('Error adding lawyer:', error);
                alert('Error: \n' + error.message);
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerText = "Register Lawyer";
                }
            }
        });
    }
}

function setupEditLawyerModal() {
    const modal = document.getElementById('edit-lawyer-modal');
    const closeBtn = document.getElementById('close-edit-lawyer-btn');
    const form = document.getElementById('edit-lawyer-form');

    if (!modal) return;

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            modal.classList.add('hidden');
        });
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerText = "Saving Changes...";
            }

            const lawyerId = document.getElementById('edit-lawyer-id').value;
            const newName = document.getElementById('edit-lawyer-fullname').value.trim();
            const newPhone = document.getElementById('edit-lawyer-phone').value.trim();
            const newSpec = document.getElementById('edit-lawyer-spec').value;

            try {
                const { error } = await supabaseClient
                    .from('profiles')
                    .update({ 
                        full_name: newName, 
                        phone: newPhone, 
                        specialization: newSpec 
                    })
                    .eq('id', lawyerId);

                if (error) throw new Error(error.message);

                alert('Lawyer profile successfully updated!');
                modal.classList.add('hidden');
                
                renderManageLawyersList();
                renderLawyerStatusWidget();
                prepareEventModal();

            } catch (error) {
                console.error('Error updating lawyer:', error);
                alert('Error updating profile: ' + error.message);
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerText = "Save Changes";
                }
            }
        });
    }
}

window.openEditLawyerModal = function(id, name, phone, spec) {
    const modal = document.getElementById('edit-lawyer-modal');
    if (!modal) return;

    document.getElementById('edit-lawyer-id').value = id;
    document.getElementById('edit-lawyer-fullname').value = name || '';
    document.getElementById('edit-lawyer-phone').value = phone || '';
    
    const specSelect = document.getElementById('edit-lawyer-spec');
    if (specSelect && spec) {
        for (let i = 0; i < specSelect.options.length; i++) {
            if (specSelect.options[i].value === spec) {
                specSelect.selectedIndex = i;
                break;
            }
        }
    }

    modal.classList.remove('hidden');
};

function setupArchiveLawyerModal() {
    const modal = document.getElementById('archive-lawyer-modal');
    const cancelBtn = document.getElementById('btn-cancel-archive-lawyer');
    const confirmBtn = document.getElementById('btn-confirm-archive-lawyer');

    if (!modal) return;

    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
            modal.classList.add('hidden');
        });
    }

    if (confirmBtn) {
        confirmBtn.addEventListener('click', async () => {
            const lawyerId = document.getElementById('archive-lawyer-id').value;
            
            confirmBtn.disabled = true;
            confirmBtn.innerText = "Archiving...";

            try {
                const { error } = await supabaseClient
                    .from('profiles')
                    .update({ status: 'inactive' })
                    .eq('id', lawyerId);

                if (error) throw new Error(error.message);

                alert('Lawyer successfully archived (set to inactive).');
                modal.classList.add('hidden');
                
                renderManageLawyersList();
                renderLawyerStatusWidget();
                prepareEventModal(); 

            } catch (error) {
                console.error('Error archiving lawyer:', error);
                alert('Error archiving lawyer: ' + error.message);
            } finally {
                confirmBtn.disabled = false;
                confirmBtn.innerText = "Archive Account";
            }
        });
    }
}

window.openArchiveLawyerModal = function(id, name) {
    const modal = document.getElementById('archive-lawyer-modal');
    const nameDisplay = document.getElementById('archive-lawyer-name-display');
    const idInput = document.getElementById('archive-lawyer-id');

    if (!modal || !nameDisplay || !idInput) return;

    idInput.value = id;
    nameDisplay.textContent = `Atty. ${name}`;
    
    modal.classList.remove('hidden');
};

async function renderManageLawyersList() {
    const listContainer = document.getElementById('manage-lawyers-list-inject');
    const countEl = document.getElementById('manage-lawyers-count');
    if (!listContainer) return;

    listContainer.innerHTML = '<p style="color:#64748b; text-align:center; padding:30px;">Loading directory...</p>';

    try {
        const { data: lawyers, error } = await supabaseClient
            .from('profiles')
            .select('*')
            .eq('role', 'lawyer')
            .eq('status', 'active') 
            .order('full_name', { ascending: true });

        if (error) throw error;

        if (lawyers && lawyers.length > 0) {
            if (countEl) countEl.textContent = `Total: ${lawyers.length}`;
            
            listContainer.innerHTML = lawyers.map(l => `
                <div style="display:flex; justify-content:space-between; align-items:center; padding: 15px; border-bottom: 1px solid #f1f5f9;">
                    <div style="display:flex; align-items:center; gap: 15px;">
                        <div style="background:#eff6ff; color:#3b82f6; width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold;">
                            ${getInitials(l.full_name)}
                        </div>
                        <div>
                            <h4 style="margin:0; font-size:14px; color:#0f172a;">Atty. ${l.full_name || 'Unknown'}</h4>
                            <p style="margin:4px 0 0 0; font-size:12px; color:#64748b;">${l.specialization || 'General Practice'} • <i class="fa-solid fa-phone" style="font-size:10px;"></i> ${l.phone || 'N/A'}</p>
                        </div>
                    </div>
                    <div style="display:flex; align-items:center; gap: 12px;">
                        <span class="tag" style="background:#dcfce7; color:#22c55e; font-size:11px; padding:4px 10px; border-radius:99px; font-weight:600;">Active</span>
                        <button onclick="openEditLawyerModal('${l.id}', '${l.full_name.replace(/'/g, "\\'")}', '${l.phone}', '${l.specialization}')" style="background:none; border:none; cursor:pointer; color:#3b82f6; padding: 5px;" title="Edit Lawyer">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                        <button onclick="openArchiveLawyerModal('${l.id}', '${l.full_name.replace(/'/g, "\\'")}')" style="background:none; border:none; cursor:pointer; color:#f59e0b; padding: 5px;" title="Archive Lawyer">
                            <i class="fa-solid fa-box-archive"></i>
                        </button>
                    </div>
                </div>
            `).join('');
        } else {
            if (countEl) countEl.textContent = `Total: 0`;
            listContainer.innerHTML = '<p style="color:#64748b; text-align:center; padding:30px;">No active lawyers found in the directory.</p>';
        }
    } catch (err) {
        console.error('Error loading lawyer directory:', err);
        listContainer.innerHTML = '<p style="color:#ef4444; text-align:center; padding:30px;">Error loading directory.</p>';
    }
}
async function renderArchivedLawyersList() {
    const listContainer = document.getElementById('manage-archived-list-inject');
    const countEl = document.getElementById('manage-archived-count');
    if (!listContainer) return;

    listContainer.innerHTML = '<p style="color:#64748b; text-align:center; padding:30px;">Loading archived lawyers...</p>';

    try {
        const { data: lawyers, error } = await supabaseClient
            .from('profiles')
            .select('*')
            .eq('role', 'lawyer')
            .eq('status', 'inactive')
            .order('full_name', { ascending: true });

        if (error) throw error;

        if (lawyers && lawyers.length > 0) {
            if (countEl) countEl.textContent = `Total Archived: ${lawyers.length}`;
            
            listContainer.innerHTML = lawyers.map(l => `
                <div style="display:flex; justify-content:space-between; align-items:center; padding: 15px; border-bottom: 1px solid #f1f5f9; background: #fafafa;">
                    <div style="display:flex; align-items:center; gap: 15px;">
                        <div style="background:#f1f5f9; color:#94a3b8; width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold;">
                            ${getInitials(l.full_name)}
                        </div>
                        <div>
                            <h4 style="margin:0; font-size:14px; color:#64748b;">Atty. ${l.full_name || 'Unknown'}</h4>
                            <p style="margin:4px 0 0 0; font-size:12px; color:#94a3b8;">${l.specialization || 'General Practice'} • <i class="fa-solid fa-phone" style="font-size:10px;"></i> ${l.phone || 'N/A'}</p>
                        </div>
                    </div>
                    <div style="display:flex; align-items:center; gap: 12px;">
                        <span class="tag" style="background:#f1f5f9; color:#94a3b8; font-size:11px; padding:4px 10px; border-radius:99px; font-weight:600;">Archived</span>
                        <button onclick="restoreArchivedLawyer('${l.id}', '${l.full_name.replace(/'/g, "\\'")}')" style="background:none; border:none; cursor:pointer; color:#22c55e; padding: 5px;" title="Restore Lawyer">
                            <i class="fa-solid fa-rotate-left"></i>
                        </button>
                    </div>
                </div>
            `).join('');
        } else {
            if (countEl) countEl.textContent = `Total Archived: 0`;
            listContainer.innerHTML = '<p style="color:#64748b; text-align:center; padding:30px;">No archived lawyers found.</p>';
        }
    } catch (err) {
        console.error('Error loading archived lawyers:', err);
        listContainer.innerHTML = '<p style="color:#ef4444; text-align:center; padding:30px;">Error loading archived lawyers.</p>';
    }
}

window.restoreArchivedLawyer = async function(id, name) {
    if (!confirm(`Are you sure you want to restore Atty. ${name}? Their account will be reactivated.`)) return;

    try {
        const { error } = await supabaseClient
            .from('profiles')
            .update({ status: 'active' })
            .eq('id', id);

        if (error) throw new Error(error.message);

        alert(`Atty. ${name} has been successfully restored!`);
        
        renderManageLawyersList();
        renderArchivedLawyersList();
        renderLawyerStatusWidget();
        prepareEventModal();

    } catch (error) {
        console.error('Error restoring lawyer:', error);
        alert('Error restoring lawyer: ' + error.message);
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const manageTabs = document.querySelectorAll('.manage-tab-btn');
    
    manageTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const targetId = this.getAttribute('data-managetab');
            if(!targetId) return;

            manageTabs.forEach(btn => {
                btn.classList.remove('active');
                btn.style.borderBottom = '2px solid transparent';
                btn.style.color = '#64748b';
                btn.style.fontWeight = '500';
            });
            
            this.classList.add('active');
            this.style.borderBottom = '2px solid #0f172a';
            this.style.color = '#0f172a';
            this.style.fontWeight = '600';

            document.querySelectorAll('.manage-tab-content').forEach(content => {
                content.classList.add('hidden');
            });
            
            const activeContent = document.getElementById(targetId);
            if(activeContent) {
                activeContent.classList.remove('hidden');
                
                if (targetId === 'manage-archived-lawyers') {
                    renderArchivedLawyersList();
                } else {
                    renderManageLawyersList();
                }
            }
        });
    });

    checkAuthAndInit();
});

document.addEventListener('DOMContentLoaded', () => {
    checkAuthAndInit();
});